#include <PTBOTAtomVX.h>

//                    S0   S1   S2   S3   S4   S5   S6   S7
int sensor_min[] = { 100, 100, 100, 100, 100, 100, 100, 100 };  // ค่าสีเขียว
int sensor_max[] = { 400, 500, 800, 700, 600, 700, 800, 600 };  // ค่าสีขาว
float power_factor = 1.0;

int line_value[] = { 0, 0, 0, 0, 0, 0, 0, 0 };
float current_degree = 0;
float previous_error_forward = 0;

//----------ค่าเซอร์โว ด้านหน้า ซ้าย----------//
#define CH_SERVO_FRONT_LEFT 2   // ช่องที่เสียบเซอร์โว ชุดปล่อยหน้า ซ้าย
int ServoFrontLeft_Lock = 95;   // ล็อคลูกบาศก์หน้า S2
int ServoFrontLeft_Drop = 50;  // ปล่อยลูกบาศก์หน้า S2

//----------ค่าเซอร์โว ด้านหน้า ขวา----------//
#define CH_SERVO_FRONT_RIGHT 1   // ช่องที่เสียบเซอร์โว ชุดปล่อยหน้า ขวา
int ServoFrontRight_Lock = 0;   // ล็อคลูกบาศก์หน้า S1
int ServoFrontRight_Drop = 55;  // ปล่อยลูกบาศก์หน้า S1

//----------ค่าเซอร์โว 0 ด้านหลัง----------//
#define CH_SERVO_BACK 0   // ช่องที่เสียบเซอร์โว ชุดปล่อยหลัง
int ServoBack_Lock = 0;   // ล็อคลูกบาศก์หลัง S0
int ServoBack_Drop = 55;  // ปล่อยลูกบาศก์หลัง S0

long delayALL = 0;
bool stateA = 0, stateB = 0, stateAB = 0;

void setup() {
  Serial.begin(115200);
  initialize();
  config();
  // ShowValue_Sensor();  // โชว์ค่าเซ็นเซอร์
  // calibrateIMU();
}

void loop() {
  STOP();
  setAngleOffset();
  current_degree = 0;
    
  Box1();
  Box2();
  Box3();
  Box4();
  Endmission();
}
